package org.ie.configurations;

import java.io.IOException;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.multipart.commons.CommonsMultipartResolver;
import org.springframework.web.servlet.ViewResolver;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurerAdapter;
import org.springframework.web.servlet.view.InternalResourceViewResolver;

@EnableWebMvc
@Configuration
@ComponentScan(basePackages = "org.ie.controllers")
public class WebConfig extends WebMvcConfigurerAdapter{
	@Bean(name = "ViewResolver")
	public InternalResourceViewResolver getJspViewResolver() {
		System.out.println("WebConfig.getJspViewResolver()");
		InternalResourceViewResolver resolver = new InternalResourceViewResolver();
		resolver.setPrefix("WEB-INF/");
		resolver.setSuffix(".html");
		resolver.setOrder(1);
		return resolver;

  }
	

    @Bean(name="multipartResolver") 
    public CommonsMultipartResolver getResolver() throws IOException{
    	System.out.println("WebConfig.getResolver()");
        CommonsMultipartResolver resolver = new CommonsMultipartResolver();             
       resolver.setMaxUploadSizePerFile(5242880);     
        return resolver;
    }
}
