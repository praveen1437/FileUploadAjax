package org.ie.controllers;

import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

public class FileUploadController {
    @PostMapping("/fileupload")
    public String upload(@RequestParam("fileup") String name,
                         @RequestParam("file")MultipartFile multipartFile){

    }
}
