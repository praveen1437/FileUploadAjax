package org.ie.dao;

import java.io.BufferedOutputStream;
import java.io.File;
import java.sql.Blob;

public class FileUploadDao {
	public boolean uploadfile(Blob blob,String name) {
		
		return false;
		
		
	}

}
