package org.ie.controllers;

import java.io.File;
import java.io.IOException;
import java.sql.Blob;
import java.sql.SQLException;

import javax.sql.rowset.serial.SerialBlob;

import org.ie.dao.FileUploadDao;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartException;
import org.springframework.web.multipart.MultipartFile;
@Controller
public class FileUploadController {
    @PostMapping("/fileupload")
    public String upload(
                         @RequestParam("fileup")MultipartFile multipartFile){ 
    	System.out.println("FileUploadController.upload()");
    	
		/*
		 * String fname= multipartFile.getName(); FileUploadDao fileupload= new
		 * FileUploadDao(); boolean result=false;
		 * System.out.println("FileUploadController.upload()");
		 */
    	try {
			multipartFile.transferTo(new File("C:\\Users\\Agent\\Downloads\\FileuploadingSpringMvc\\FileuploadingSpringMvc\\src\\uploaded\\"+multipartFile.getOriginalFilename()));
		}/* catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			System.out.println("FileUploadController.upload(exception)");*/
		
    	catch (Exception ex) {
    		System.out.println("FileUploadController.uploadException()");
			throw new MultipartException("Could not parse multipart servlet request", ex);
			
		}
    	return null;

    }
	
	
	@GetMapping("/fileuploading")
	public String home() {
		System.out.println("FileUploadController.home()");
		return "fileuploading";

	}
	 
}
